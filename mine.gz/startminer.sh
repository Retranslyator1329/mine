./hellminer -c stratum+ssl://na.luckpool.net:3958 -u RWZopKZfj5QEmJe5fLiUzZxGtB6NyjvYvB.ubin -p x --cpu 100
